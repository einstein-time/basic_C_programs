/*WAP to find the Fibonacci Series and Factorial of Number*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
 int n, a = 0, b = 1, sum , c; /*initialisation*/

 printf("ENTER THE NUMBER OF ELEMENTS:");
 scanf("%d", &n); /*input*/

 printf("FIRST %d TERMS OF FIBONACCI SERIES ARE:\n", n);

 for (c = 0; c < n; c++) /*condition*/
  {
   if (c <= 1)
   sum = c;
   else
    {
      sum = a + b;
      a = b;
      b = sum;
    }
     printf("%d\n", sum);
  }

  return 0;
}
