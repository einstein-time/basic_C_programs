#include <stdio.h>
#include <stdlib.h>

int main()
{

   int n,i;
   int sum=0;
   printf("ENTER THE MAXIMUM VALUE OF SERIES: ");
   scanf("%d",&n); /*INPUT*/
   sum = (n * (n + 1)) / 2; /*FORMULA*/
   printf("SUM OF SERIES IS: ");
   for (i =1;i <= n;i++)
{
	if (i!=n)
	printf("%d + ",i); else
	printf("%d = %d ",i,sum);
}
}

