#include <stdio.h>
#include <math.h>

int main()
{
  int cosValue, number;
  printf(" Please Enter the Value to calculate Cosine :  ");
  scanf("%f", &number);
  cosValue = cos(number);
  printf("\n Cosine value of %f = %f ", number, cosValue);
  return 0;
}
