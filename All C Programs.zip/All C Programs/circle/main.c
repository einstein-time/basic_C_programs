#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
  float x,y,r,a,b,s;
  printf("ENTER POSITION OF POINT a OF CIRCLE:");
  scanf("%f",&a);
  printf("ENTER POSITION OF POINT b OF CIRCLE:");
  scanf("%f",&b);

  /*POSITION OF RADIUS*/
  s = sqrt((a*a)+(b*b));

  /*THE POINT*/
  printf("ENTER POSITION OF X:");
  scanf("%f",&x);
  printf("ENTER POSITION OF Y:");
  scanf("%f",&y);

  r=sqrt((x*x+(y*y)));


  if (r==s)
  {
      printf("THE POINT LIES ON THE CIRCLE");
  }
  else
  {
     if (r<s)
     {
         printf("THE POINT LIES INSIDE THE CIRCLE");
     }
     else
     {
         printf("THE POINT LIES OUTSIDE THE CIRCLE");
     }
  }
}
