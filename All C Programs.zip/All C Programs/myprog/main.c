#include <stdio.h>
#include <stdlib.h>

int main()
{
 /* THIS IS MY FIRST BUT SEOND PROGRAM*/


 char first_name[20];
 char last_name[20];
 char city[20];
 char occupation [20];
 char age[3];

 printf(" Please enter your first name :\n");
 scanf("%s", & first_name);
 printf(" Please enter your last name:\n");
 scanf("%s", & last_name);
 printf("  Enter your age:\n");
 scanf("%s", &age);
 printf(" Enter name of your city:\n",city);
 scanf("%s",&city);
 printf(" Enter your occupation:\n",occupation);
 scanf("%s",occupation);
 printf(" Name:%s \n Last name:%s \n Age:%s \n City:%s \n Occupation:%s ", first_name , last_name ,age , city , occupation  );
   }
