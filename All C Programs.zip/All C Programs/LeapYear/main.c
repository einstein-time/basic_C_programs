#include <stdio.h>
#include <stdlib.h>

int main()
{
    int year;

    printf("ENTER ANY YEAR TO CHECK WHETHER IT IS LEAP YEAR:\n");
    scanf("%d",&year);

    if (year%4 == 0)
    {
     if (year%100==0)
     {
      if(year%400==0)
      printf("THE YEAR IS LEAP YEAR");

      else
      printf("THE YEAR IS NOT LEAP YEAR");
     }
    else
    printf("THE YEAR IS NOT LEAP YEAR");
    }
    else
    printf("THE YEAR IS NOT LEAP YEAR");


}
