#include <stdio.h>
#include <stdlib.h>

int main()
{
 int a1=0,a2=1,a3,b,num;
 printf("ENTER THE NUMBER OF ELEMENTS:");
 scanf("%d",&num);
 printf("\n%d %d",a1,a2);//printing 0 and 1
 for(b=2;b<num;++b)//loop starts from 2 because 0 and 1 are already printed
 {
  a3=a1+a2;
  printf(" %d",a3);
  a1=a2;
  a2=a3;
 }
  return 0;
}
