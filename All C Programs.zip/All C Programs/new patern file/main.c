#include <stdio.h>
#include <stdlib.h>

int main()
{
    int p,q;
    char input,alpha='A';
    printf("ENTER THE LAST ALPHABET OF SERIES\n");
    scanf("%c", &input);
    for(p=1;p<=(input-'A'+1);p++)
    {
        for(q=(input-'A'+1);q>=p;q--)
        {
            printf("%c",'A'-1+p);
        }
        printf("\n");
    }
}
