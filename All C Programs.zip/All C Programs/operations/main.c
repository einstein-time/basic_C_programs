#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1,num2,num3,num4,num5,num6,addition,substraction,multiplication;
    float num7,num8,division;

    printf("Enter number:\n");
    scanf("%d,&num1");
    printf("Enter number:\n");
    scanf("%d,&num2");
    addition=num1+num2;
    printf("\nThe result of addition is:%d",addition);

    printf("Enter number:\n");
    scanf("%d,&num3");
    printf("Enter number:\n");
    scanf("%d,&num4");
    substraction=num3-num4;
    printf("\nThe result of substraction is:%d",substraction);

    printf("Enter number:\n");
    scanf("%d,&num5");
    printf("Enter number:\n");
    scanf("%d,&num6");
    multiplication=num5*num6;
    printf("\nThe reult of multiplication is:%d",multiplication);

    printf("Enter number:\n");
    scanf("%f,&num7");
    printf("Enter number:\n");
    scanf("%f,&num8");
    division=num7/num8;
    printf("\nThe result of multiplication is:%d",division);
    }

