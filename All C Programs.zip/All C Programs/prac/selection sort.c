#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[100],i,j,m,n,position,swap;
    printf("enter number of elements\n");
    scanf("%d",&n);
    printf("enter %d digits\n",n);
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for (i=0;i<n-1;i++)
    {
        position=i;
        for (j=i+1;j<n;j++)
        {
            if (a[position]>a[j])
            {
                position =j;
            }
            if(position!=0)
            {
                swap=a[i];
                a[i]=a[position];
                a[position]=swap;
            }

        }printf("sort array \n");
        for (i=0;i<n;i++)
            printf("%d\n",a[i]);

    }

}
