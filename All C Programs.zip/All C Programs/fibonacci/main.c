#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,first=0,second=1,next,c;
    printf("enter number of digits:\n");
    scanf("%d",&n);
    printf("first %d terms of series are:\n",n);
    for(c=0;c<n;c++)
    {
        if (c<=1)
        next=c;
        else
        {
            next=first+second;
            first=second;
            second=next;

        }
     }
      printf("%d\n",next);
}
