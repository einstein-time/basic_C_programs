#include <stdio.h>
#include <stdlib.h>

int main()
{
    int marks;
    printf("ENTER YOUR MARKS: ");
    scanf("%d",&marks);

    if (marks<0 || marks>100)
    printf("ERROR!!!");

    else if(marks<50)
    {
        printf("YOUR GRADE IS F... STUDY HARD!!!");
    }
    else if(marks>=50 && marks<60)
    {
        printf("YOUR GRADES ARE SATISFACTORY BUT STUDY HARDER!!! \nYOUR GRADE IS D");
    }
    else if(marks>=60 && marks<70)
    {
        printf("YOUR GRADES ARE GOOD...CAN DO BETTER!! ... YOUR GRADE IS C");
    }
    else if(marks>=70 && marks<80)
    {
        printf("YOUR MARKS ARE VERY GOOD .... YOUR GRADE IS B!!!");
    }
    else if(marks>=80 && marks<90)
    {
        printf("YOU ARE EXCELLENT AT STUDIES!!! YOUR GRADE IS A");
    }
    else
    {
        printf("YOU HAVE SHOWN OUTSTANDING PERFORMANCCE .... KEEP IT UP ... YOUR GRADE IS A++");
    }
}


