1.#include <stdio.h>
2.
3.	int main()
4.	{
5.	   int n, reverse = 0, t;
6.
7.	   printf("Enter a number to check if it is a palindrome or not\n");
8.	   scanf("%d", &n);
9.
10.	   t = n;
11.
12.	   while (t != 0)
13.	   {
14.	      reverse = reverse * 10;
15.	      reverse = reverse + t%10;
16.	      t = t/10;
17.	   }
18.
19.	   if (n == reverse)
20.	      printf("%d is a palindrome number.\n", n);
21.	   else
22.	      printf("%d isn't a palindrome number.\n", n);
23.
24.	   return 0;
25.	}
