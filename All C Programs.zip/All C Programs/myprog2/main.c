#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1 , num2 , division;
    printf("Please enter first number:");
    scanf("%d", &num1);
    printf("Please enter second number:");
    scanf("%d", &num2);
    division= num1/num2;
    printf("Result is:%d",division);
}
