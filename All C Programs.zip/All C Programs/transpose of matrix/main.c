#include <stdio.h>
#include <stdlib.h>

int main()
{
   int m,n,c,d,a[10][10],trans[10][10];
   printf("enter row and columns:\n");
   scanf("%d%d",&m,&n);
   printf("enter values of matrix:\n");
   for(c=0;c<m;c++)
   for(d=0;d<n;d++)
   scanf("%d",&a[c][d]);

   for(c=0;c<m;++c)
   for(d=0;d<n;++d)
   {
       trans[d][c]=a[c][d];
   }
       printf("transpose of matrix is:\n");
       for(c=0;c<m;c++)
   for(d=0;d<n;d++)
   {
       printf("%d",trans[c][d]);
       if (d==m-1)
        printf("\n\n");
   }
}
