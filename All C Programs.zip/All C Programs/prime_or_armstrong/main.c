#include <stdio.h>
#include <math.h>
int PrimeNumber(int n);
int ArmstrongNumber(int n);
int main()
{
    int n, m;
    printf("ENTER A POSITIVE INTEGER: ");
    scanf("%d", &n);
    // Check prime number
    m = PrimeNumber(n);
    if (m == 1)
        printf("%d IS A PRIME NUMBER.\n", n);
    else
        printf("%d IS NOT A PRIME NUMBER.\n", n);
    // Check Armstrong number
    m = ArmstrongNumber(n);
    if (m == 1)
        printf("%d IS AN ARMSTRONG NUMBER.", n);
    else
        printf("%d IS NOT AN ARMSTRONG NUMBER.",n);
    return 0;
}
int PrimeNumber(int n)
{
    int i, m = 1;
    for(i=2; i<=n/2; ++i)
    {
    // condition for non-prime number
        if(n%i == 0)
        {
            m = 0;
            break;
        }
    }
    return m;
}
int ArmstrongNumber(int num)
{
    int originalNum, remainder, result = 0, n = 0, m;
    originalNum = num;
    while (originalNum != 0)
    {
        originalNum /= 10;
        ++n;
    }
    originalNum = num;
    while (originalNum != 0)
    {
        remainder = originalNum%10;
        result += pow(remainder, n);
        originalNum /= 10;
    }
    // condition for Armstrong number
    if(result == num)
        m = 1;
    else
        m = 0;
    return m;
}
