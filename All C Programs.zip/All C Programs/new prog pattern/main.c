#include <stdio.h>
#include <stdlib.h>

int main()
{
   int i,j;
   char input,alphabet='A';

   printf("ENTER LAST LETTER IN SERIES:\n");
   scanf("%c", &input);
   for(i=1;i<=(input-'A' =1);i++)
   {
       for(j=(input-'A'+1);j>1;j--)
       {
           printf("%c", 'A'-1+i);
       }
       printf("\n");
   }
}
