#include <stdio.h>
#include <stdlib.h>

int main()
{
int i , j = 3;
scanf("xyz(&i,&j));
printf(�%d%d�,i,j);
}
xyz(int *i , int*j)
{
*i = *i * *j;
*j = *j * *j;
}
}
