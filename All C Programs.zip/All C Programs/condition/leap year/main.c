#include <stdio.h>
#include <stdlib.h>

int main()
{
   int a;
   printf("enter year\n");
   scanf("%d",&a);
   if (a%4==0)
   {
       if (a%100==0)
       {
           if (a%400==0)
            printf("leap year");
           else
            printf("not leap");
       }
       else
       printf("leap year");

   }
   else
    printf("not leap year");
}
