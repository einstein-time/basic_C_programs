#include <stdio.h>
#include <math.h>

int main()
{
    int a,b,c,dis;
    float x1,x2;

    printf("enter the coefficient:");
    scanf("%d%d%d",&a,&b,&c);

    dis=(b*b)-(4*a*c);printf("Discriminant is %d",dis);

    if (dis==0)
    {
     printf("Roots are real and equal");
     x1=-b/(2*a);
     x1=x2;
     printf("First root x1=%f",x1);
     printf("Second root x2=%f",x2);
    }
    else if (dis>0)
    {
     printf("Roots are real and different");
    }

    {
    x1=(-b+sqrt(dis)/(2*a));
    x2=(-b+sqrt(dis)/(2*a));

    printf("First root is x1=%f",x1);
    printf("Second root is x2=%f",x2);
    }
    else (dis<0);
    {
     printf("The roots are imaginary");
    }
}
