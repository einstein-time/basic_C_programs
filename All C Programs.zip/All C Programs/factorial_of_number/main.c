/*WAP to find the factorial of a number*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num,a;
    long int fact;

    printf("ENTER AN INTEGER: ");
    scanf("%d",&num);

    /*product of numbers from num to 1*/
    fact=1;
    for(a=num; a>=1; a--)
    fact=fact*a;

    printf("\nFACTORIAL OF %d IS = %ld",num,fact);

    return 0;
}
