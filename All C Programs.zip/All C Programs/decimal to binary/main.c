#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c;
    printf("Please enter a number in base 10: ");
    scanf("%d",&a);
    printf("\nPlease enter the base that you want the number to be converted to: ");
    scanf("%d",&b);
    do
    {
        c=a%b;
        printf("%d",c);
        a/=b;
    }
    while(c!=0);

}
